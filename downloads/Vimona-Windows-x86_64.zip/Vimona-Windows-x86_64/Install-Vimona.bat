@echo off
setlocal
title Vimona Windows Setup
cd /d "%~dp0"
echo [Vimona] Installing Windows desktop app, GTK4 runtime, and shortcuts...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installers\install-windows.ps1" %*
if errorlevel 1 (
    echo.
    echo [Vimona] Setup encountered an error. Check messages above.
    pause
    exit /b 1
)
echo.
echo [Vimona] Setup finished cleanly. Launching Vimona...
call "%~dp0Launch-Vimona.bat"
