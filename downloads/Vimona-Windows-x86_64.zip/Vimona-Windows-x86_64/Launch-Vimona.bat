@echo off
setlocal
cd /d "%~dp0"
set "VIMONA_HOME=%LOCALAPPDATA%\Vimona"
set "APP_ROOT=%~dp0"
if exist "%VIMONA_HOME%\run_vimona.py" set "APP_ROOT=%VIMONA_HOME%\"
set "PATH=C:\msys64\ucrt64\bin;%LOCALAPPDATA%\msys64\ucrt64\bin;%PATH%"
set "PY_BIN=C:\msys64\ucrt64\bin\python3.exe"
if not exist "%PY_BIN%" set "PY_BIN=%LOCALAPPDATA%\msys64\ucrt64\bin\python3.exe"
if not exist "%PY_BIN%" (
    echo [Vimona] First-run setup required to install GTK4 + Python runtime...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installers\install-windows.ps1"
    if errorlevel 1 (
        pause
        exit /b 1
    )
)
if not exist "%PY_BIN%" set "PY_BIN=python"
set "PYTHONPATH=%APP_ROOT%;%PYTHONPATH%"
start "" "%PY_BIN%" "%APP_ROOT%run_vimona.py" %*
